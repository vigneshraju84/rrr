from django.shortcuts import render,redirect
from datetime import date, timedelta
import datetime
import re
from django.contrib import messages
from datetime import datetime, date
from django.conf import settings
from django.template.loader import render_to_string
from django.http import HttpResponse
import json
from django.http import JsonResponse
from admin_settings.models import Projects
from admin_settings.models import Enquiries

# Create your views here.
def home(request):
	
	return render(request,'index.html',{})

def current_projects(request):
	project_info = Projects.objects.filter(type=1,visible=1)
	image_url = settings.SITE_URL
	return render(request,'current_projects.html',{'project_info':project_info,'image_url':image_url})
	
def completed_projects(request):

	project_info = Projects.objects.filter(type=2,visible=1)
	image_url = settings.SITE_URL
	return render(request,'completed_projects.html',{'project_info':project_info,'image_url':image_url})


def upcomming_projects(request):

	project_info = Projects.objects.filter(type=3,visible=1)
	image_url = settings.SITE_URL
	return render(request,'upcomming_projects.html',{'project_info':project_info,'image_url':image_url})
	
def contact_us(request):
	name=email=phone=subject=messages=""
	error_msg=""
	if request.method == "POST":
		if request.POST.get("name"):
			name = request.POST.get("name")
		if request.POST.get("email"):
			email = request.POST.get("email")
		if request.POST.get("phone"):
			phone =request.POST.get("phone")
		if request.POST.get("subject"):
			subject = request.POST.get("subject")
		if request.POST.get("messages"):
			messages = request.POST.get("messages")
		
		if name and phone:
			Projects(name=name,email=email,phone=phone,subject=subject,messages=messages).save()
			return HttpResponseRedirect("/contact_us")
		else:
			error_msg="Name and Phone number required"
			
	return render(request,'contact_us.html',{'error_msg':error_msg})

def terms_conditions(request):

    return render(request,'term-condition.html')

def privacy_policy(request):

    return render(request,'privacy-policy.html')   
    