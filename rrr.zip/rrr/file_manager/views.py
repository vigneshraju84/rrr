from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate, login 
from file_manager.forms import FileManagerForm 
from django.contrib.auth import get_user_model
from django.utils.html import strip_tags
from django.contrib.auth.models import Group, User
from datetime import date, timedelta
import datetime
import re
from file_manager.models import FileManager 
from django.contrib import messages
from django.contrib.auth import logout
from datetime import datetime, date
from django.conf import settings
from django.contrib.auth.decorators import login_required
import re
import base64
import math
import csv 
from django.core.files.storage import FileSystemStorage
import os
from user_requests.models import RequestDocumentMap
import dropbox
 
dbx = dropbox.Dropbox(settings.DROPBOX_ACCESS_TOKEN, timeout=None)

# Create your views here.
 
@login_required(login_url='/accounts/login/')    
def file_manager_add(request):

    country=mail_error=country_res=error_email=file_name_data=error_msg="" 
    if request.method == "POST":    
        form={} 
        form = FileManagerForm(request.POST, request.FILES)  
        
        if form.is_valid():
         
            title = request.POST.get('title','')
            # file_url = request.POST.get('file_url','')
            user_id = request.user.id
            status = 1   
            created_on = datetime.utcnow() 
            created_by = request.user.id  
            
            context = {}
            
            if request.FILES['file_url']:
                uploaded_file =  request.FILES['file_url']
                # print(uploaded_file)
                 
                dt = datetime.utcnow()
                date = dt.strftime("%Y%m%d%H%M%S")
                fle_name = os.path.splitext(uploaded_file.name)[0]
                file_name = fle_name + date
                file_name = file_name + os.path.splitext(uploaded_file.name)[1]
                # print(file_name)
                key_store = FileSystemStorage()
                fl_name = key_store.save(file_name, uploaded_file)
                context['url'] = key_store.url(fl_name)
                file_name_data = context['url']
                # fle = './' + file_name_data
                fle = settings.DROPUP_URL + file_name
                with open(fle, "rb") as f:
                    result = dbx.files_upload(f.read(), '/'+ request.user.username +'/'+ file_name , mute = True, mode=dropbox.files.WriteMode.overwrite)
                    
                    # shared_link_metadata = dbx.sharing_create_shared_link_with_settings(result.path_display)
                    # dropbox_url = shared_link_metadata.url
                    # dropbox_url = dropbox_url.replace('dl=0', 'dl=1')
                try:
                    shared_link_metadata = dbx.sharing_create_shared_link_with_settings(result.path_display)
                    dropbox_url = shared_link_metadata.url
                    dropbox_url = dropbox_url.replace('dl=0', 'dl=1')
                    form_info = FileManager(user_id=user_id,title=title,file_url=dropbox_url,status=status,created_on=created_on,created_by=created_by)
                    form_info.save()
                    if os.path.join(settings.MEDIA_ROOT, uploaded_file.name): 
                        os.remove(os.path.join(settings.MEDIA_ROOT, file_name))
                        
                    messages.success(request, 'File Manager created successfully.')
                    return redirect('/file_manager/') 
                except:
                    error_msg = "Error While File upload "
    else:   
        form = FileManagerForm()

    return render(request,'file_manager_add.html',{'form':form,'mail_error':mail_error,'error_msg':error_msg})

@login_required(login_url='/accounts/login/')
def file_manager(request):

	sql = where_str =search_val= "" 
	# sorting starts
	sort_str=""
	varSortColumn="created_on"
	varSortOrderVal="DESC"
	if request.POST.get('varSortOrder'):
		varSortOrderVal = request.POST.get('varSortOrder')
	
	if request.POST.get('varSortCol'):
		varSortColumn = request.POST.get('varSortCol')
		
	sort_str = " ORDER BY " + varSortColumn + " " + varSortOrderVal
	# sorting ends
		
	where_str = " AND user_id = %s" % request.user.id 
    #paginations starts

	varPageNo = settings.PAGE_NO
	rec_count = settings.REC_PER_PAGE

	if request.POST.get('count'):
		rec_count = request.POST.get('count')
        
	if request.POST.get('varPageNo'):
		varPageNo = request.POST.get('varPageNo')
        
	pageNo = int(varPageNo) - int(1)

	start_from = int(pageNo) * int(rec_count)

	pagination = " LIMIT " + str(start_from) + "," + str(rec_count)

	page_sql = "SELECT * FROM hex_file_manager WHERE status = 1"+ where_str + sort_str
	
	page_cnt = FileManager.objects.raw(page_sql)

	rec_count_value=settings.REC_COUNT

	page_cnt = len(page_cnt)
	no = int(page_cnt)/int(rec_count)

	total_pages = math.ceil(no);
	startRec=1
	endRec=""
	if int(varPageNo) == 1:
		if int(page_cnt) < int(rec_count):
			endRec = page_cnt
		else:
			endRec = rec_count
	else:
		startRec = int(rec_count) * int(pageNo)
		endRec   = int(startRec) + int(rec_count)
		if int(endRec) > int(page_cnt):
			endRec = page_cnt
        
		startRec += 1

    #paginations ends
   
 
	sql = "SELECT * FROM hex_file_manager WHERE status = 1 " + where_str + sort_str + pagination
	
	file_manager_ress = FileManager.objects.raw(sql)
	# print(file_manager_ress)
	  
	# search_val = {
		# # 'facility' : request.POST.get('facility'),
		# # 'med_dir_id' : request.POST.get('med_dir_id')
	# } 
    
	return render(request,"file_manager.html",{'file_manager_res':file_manager_ress,'endRec':endRec,'startRec':startRec,'total_pages':range(total_pages),'page_cnt':page_cnt,'varPageNo':int(varPageNo),'total_no':int(total_pages),'rec_count':int(rec_count),'rec_count_value':rec_count_value,'tatal_rec' : page_cnt,'search_val':search_val,'varSortCol':varSortColumn,'varSortOrder':varSortOrderVal})
    
    

    
@login_required(login_url='/accounts/login/')	
def file_manager_edit(request, id):  
	
	file_manager = FileManager.objects.get(id=id)
	
	return render(request,'file_manager_edit.html', {'file_manager':file_manager})

@login_required(login_url='/accounts/login/')	
def file_manager_delete(request, id):  
       
    up = FileManager.objects.get(id=id) 
    FileManager.objects.get(id=id).delete()
    
    # dbx.files_delete(up.file_url)
    
    messages.success(request, 'File Manager deleted successfully.')
    
    return redirect("/file_manager/")

def file_manager_download(request, id):  
   
        
    up = FileManager.objects.get(id=id)  
    res = dbx.files_download(up.file_url)
    print(res)
    messages.success(request, 'File Downloaded successfully.')
    
    return redirect("/file_manager/")


@login_required(login_url='/accounts/login/')	
def file_manager_update(request, id):  
	file_manager=""
	file_manager = FileManager.objects.get(id=id)
    # request.POST['id']=id
	form = FileManagerForm(request.POST)  
	print(form.errors)
	if form.is_valid():
		title = request.POST.get('title','')
		file_url = request.POST.get('file_url','')
		# status = request.POST.get('status','')
		modified_on = datetime.utcnow() 
		modified_by = request.user.id
		 
		up = FileManager.objects.filter(id=id).update(title=title,file_url=file_url,modified_on=modified_on,modified_by=modified_by)
		
		# form_info.save()
		messages.success(request, 'File Manager updated successfully.')
		return redirect("/file_manager")  
	return render(request, 'file_manager_edit.html', {'file_manager': file_manager,'form':form})

