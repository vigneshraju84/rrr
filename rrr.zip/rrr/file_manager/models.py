from django.db import models

# Create your models here.
# Create your models here.
class FileManager(models.Model):
	id			= models.AutoField(primary_key=True)
	user_id		= models.IntegerField(null=True) 
	title	= models.CharField(max_length=250, null=True) 
	file_url	= models.TextField(null=True) 
	status		= models.SmallIntegerField(null=True)
	created_on	= models.DateTimeField(null=True)
	created_by	= models.IntegerField(null=True)
	modified_on	= models.DateTimeField(null=True)
	modified_by	= models.IntegerField(null=True) 
	class Meta:
		db_table = "hex_file_manager"
