from django import forms
from file_manager.models import FileManager  
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from datetime import datetime
import re

class FileManagerForm(forms.Form):

	# class Meta:
		# model = Clients
		# #fields = "__all__"
		# fields = ['first_name', 'entity_name','email','address_1','city','state','country','zip_code','phone','status']
	  
	# username = forms.CharField(required=False)	
	title = forms.CharField(error_messages={'required': 'This field is required'})
	file_url = forms.FileField(error_messages={'required': 'Please Choose file'})
	
        

