from django import forms
from common.models import Customer 
from common.models import HexSymptoms
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from datetime import datetime
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, UserChangeForm

import re
from django.contrib.auth.forms import PasswordResetForm

class CustomerForm(forms.Form):

	# class Meta:
		# model = Clients
		# #fields = "__all__"
		# fields = ['first_name', 'entity_name','email','address_1','city','state','country','zip_code','phone','status']
	last_name = forms.CharField(required=False)	
	# username = forms.CharField(required=False)	
	first_name = forms.CharField(error_messages={'required': 'This field is required'})
	# userame = forms.CharField(error_messages={'required': 'This field is required'})
	gender = forms.CharField(required=False)	
	dob = forms.CharField(required=False)	
	country_code = forms.CharField(required=False)	
	mobile_no = forms.CharField(required=False)	
	country = forms.CharField(required=False)	
	# dob = forms.CharField(error_messages={'required': 'This field is required'})
	# country_code = forms.CharField(error_messages={'required': 'Empty or invalid country code'})
	# mobile_no = forms.CharField(error_messages={'required': 'This field is required'})
	# country_code = forms.CharField(error_messages={'required': 'This field is required'}) 
	# country = forms.CharField(error_messages={'required': 'This field is required'}) 
	# facility = forms.CharField(required=False)
	# med_dir_id = forms.CharField(error_messages={'required': 'Empty or invalid Medical Director'}) 
	# entity_name = forms.CharField(error_messages={'required': 'Empty or invalid Practice Name'})
	# address_1 = forms.CharField(error_messages={'required': 'Empty or invalid Address 1'})
	# email = forms.CharField(error_messages={'required': 'Empty or invalid Email'})
	# city = forms.CharField(error_messages={'required': 'Empty or invalid City'})
	# state = forms.CharField(error_messages={'required': 'Empty or invalid State'})
	# country = forms.CharField(error_messages={'required': 'Empty or invalid Country'})
	# zip_code = forms.CharField(error_messages={'required': 'Empty or invalid Zip Code'})
	# phone = forms.CharField(error_messages={'required': 'Empty or invalid Phone'})
	# fax = forms.CharField(required=False)
	# status = forms.CharField(error_messages={'required': 'Empty or invalid Status'})
	'''
	def clean_email(self):
		email = self.cleaned_data['email']
		
		if Clients.objects.filter(email=email).exists():
			raise ValidationError('Email already exist.')
			
		validate_email(email)

		return email
	'''
	def clean_mobile_no(self):
		cd = self.cleaned_data 
		mobile_no = cd.get('mobile_no') 
		if re.match(r'^\d{10}$',mobile_no):   
			print('YES')
		else:  
			msg = "Empty or invalid mobile no"
			self.add_error('mobile_no', msg)
			
	      
	# def clean_username(self):
		# cd = self.cleaned_data 
		# username = cd.get('username') 
		# if re.match(r'^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$',username):   
			# print('YES')
		# else:  
			# msg = "Empty or invalid email"
			# self.add_error('username', msg)
			
			
            
            
	# def clean(self):
		# cleaned_data = super().clean()
		# facility = cleaned_data.get("facility")
		# # zip_code = cleaned_data.get("zip_code")
		# # facility = cleaned_data.get("facility")
        
		
		# facility_text = cleaned_data.get("facility_text")
		
		# if facility =="" and facility_text == "": 
			# msg = "Empty or invalid Health System"
			# self.add_error('facility', msg)
			
class SymptomsForm(forms.Form):		
		
	sym_name = forms.CharField(error_messages={'required': 'Empty or invalid symptoms'})
    
class SpecialtiesForm(forms.Form):		
		
	name = forms.CharField(error_messages={'required': 'Empty or invalid name'})
	 
class HealthConditionsForm(forms.Form):		
		
	name = forms.CharField(error_messages={'required': 'Empty or invalid name'})
	 


class EmailValidationOnForgotPassword(PasswordResetForm):

    def clean_email(self):
        email = self.cleaned_data['email']
        if not User.objects.filter(username__iexact=email, is_active=True).exists():
            msg = "There is no user registered with the specified E-Mail address."
            self.add_error('email', msg)
        return email
