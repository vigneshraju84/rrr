from django.db import models

# Create your models here.
class Admin_user(models.Model):
	id			= models.AutoField(primary_key=True)
	user_name 	= models.CharField(max_length=100, null=True)
	password 	= models.CharField(max_length=100, null=True)
	first_name	= models.CharField(max_length=100, null=True)
	last_name	= models.CharField(max_length=100, null=True)
	email		= models.CharField(max_length=250, null=True) 
	mobile_no	= models.CharField(max_length=100, null=True) 
	gender	= models.SmallIntegerField(null=True)
	dob	= models.DateField(null=True)
	status		= models.SmallIntegerField(null=True)
	created_on	= models.DateTimeField(null=True)
	created_by	= models.IntegerField(null=True)
	modified_on	= models.DateTimeField(null=True)
	modified_by	= models.IntegerField(null=True) 
	class Meta:
		db_table = "rrr_admin_user"
        
class Projects(models.Model):
	id			= models.AutoField(primary_key=True)
	name		= models.CharField(max_length=100, null=True)
	image		= models.CharField(max_length=250, null=True)
	description = models.TextField(null=True)
	type		= models.SmallIntegerField(null=True)
	visible		= models.SmallIntegerField(null=True)
	sort_order	= models.SmallIntegerField(null=True)
	created_on	= models.DateTimeField(null=True)
	created_by	= models.IntegerField(null=True)
	modified_on	= models.DateTimeField(null=True)
	modified_by	= models.IntegerField(null=True) 
	
	class Meta:
		db_table = "rrr_projects"
class Enquiries(models.Model):
	id			= models.AutoField(primary_key=True)
	name		= models.CharField(max_length=100, null=True)
	email		= models.CharField(max_length=250, null=True)
	phone		= models.CharField(max_length=250, null=True)
	subject		= models.CharField(max_length=250, null=True)
	message		 = models.TextField(null=True)
	created_on	= models.DateTimeField(null=True)
	
	class Meta:
		db_table = "rrr_enquiries"
    