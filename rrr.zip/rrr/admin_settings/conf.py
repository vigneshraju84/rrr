from django.contrib.auth import authenticate, login 
# from common.forms import CustomerForm
# from common.forms import SymptomsForm
# from common.forms import SpecialtiesForm
# from common.forms import HealthConditionsForm
from django.contrib.auth import get_user_model
from django.utils.html import strip_tags
from django.contrib.auth.models import Group, User
from datetime import date, timedelta
import datetime
from django.contrib.auth import logout
from datetime import datetime, date
from django.conf import settings
from django.contrib.auth.decorators import login_required
from common.models import Customer
from doctor.models import Doctor 
from django.utils.deprecation import MiddlewareMixin
from django.http import HttpResponsePermanentRedirect

def var(request):
    #left_menu
    left_menu={}
    pro_details={}
    login_user_group = list(request.user.groups.values_list('name',flat = True))
    
    if "admin" in login_user_group :
        left_menu={
            #"<i class='fas fa-columns'></i><span>Admin Dashboard</span>"
															
            "/dashboard":{"class":"fas fa-columns","link_name":"Admin Dashboard"},
            
            "/doctor_list":{"class":"fas fa-user-injured","link_name":"Doctors"},
            "/customer":{"class":"fas fa-user-injured","link_name":"Customers"},    
            "/my_requests":{"class":"fas fa-calendar-check","link_name":"Requests"},
            #"/request_history":{"class":"fas fa-file-invoice","link_name":"Requests History"},
            "/my_appointments":{"class":"fas fa-calendar-check","link_name":"Appointments"},
            "/payments":{"class":"fas fa-user-injured","link_name":"Payments"},
            #"/manage-symptoms/":{"class":"fas fa-share-alt","link_name":"Manage Symptoms"},
            #"/manage-specialties/":{"class":"fas fa-share-alt","link_name":"Manage Specialties"},
            #"/manage-health_conditions/":{"class":"fas fa-share-alt","link_name":"Manage Health Conditions"},
            
            "/symptoms":{"class":"fas fa-share-alt","link_name":"Symptoms"},
            "/specialties":{"class":"fas fa-share-alt","link_name":"Specialities"},
            "/health_conditions":{"class":"fas fa-share-alt","link_name":"Health Conditions"},
            # "/profile-settings":{"class":"fas fa-user-cog","link_name":"Profile Settings"},
            "/change-password":{"class":"fas fa-lock","link_name":"Change Password"},
            "/logout":{"class":"fas fa-sign-out-alt","link_name":"Logout"}

        }
        pro_details = {
        "Name":"ADMIN",
        "designation":""
        }
        
    if "customer" in login_user_group :
        left_menu={
            "/dashboard":{"class":"fas fa-columns","link_name":"Customer Dashboard"},
            "/my_requests":{"class":"fas fa-calendar-check","link_name":"My Requests"},
            "/my_appointments":{"class":"fas fa-calendar-check","link_name":"My Appointments"},
            "/file_manager":{"class":"fas fa-user-injured","link_name":"My Storage"},
            "/payments":{"class":"fas fa-user-injured","link_name":"My Payments"},
            "/profile-settings":{"class":"fas fa-user-cog","link_name":"Profile Settings"},
            "/change-password":{"class":"fas fa-lock","link_name":"Change Password"},
            "/logout":{"class":"fas fa-sign-out-alt","link_name":"Logout"}      
        }
        user_id=request.user.id
        details = Customer.objects.get(user_id=user_id)
        name = details.first_name+ " " +details.last_name
        pro_details = {
        "Name":name,
        "designation":""
        }
        
    if "doctor" in login_user_group :
        left_menu={
            "/dashboard":{"class":"fas fa-columns","link_name":"Doctor Dashboard"},
            "/my_requests":{"class":"fas fa-calendar-check","link_name":"Request Recieved"},
            "/my_appointments":{"class":"fas fa-calendar-check","link_name":"My Appointments"},
            "/file_manager":{"class":"fas fa-user-injured","link_name":"My Storage"},
            "/payments":{"class":"fas fa-user-injured","link_name":"My Payments"},
            "/profile-settings":{"class":"fas fa-user-cog","link_name":"Profile Settings"},
            "/change-password":{"class":"fas fa-lock","link_name":"Change Password"},
            "/logout":{"class":"fas fa-sign-out-alt","link_name":"Logout"}      
        }
        name=""
        designation=""
        user_id=request.user.id
        details = Doctor.objects.filter(user_id=user_id)
        for val in details:
            name = val.first_name+ " " +val.last_name
            designation=val.designation
        pro_details = {
        "Name":name,
        "designation":designation
        }
    
    return {
        'left_menu':left_menu,'pro_details':pro_details,'path':request.path
    }   
      
    
from django.template.defaulttags import register
...
@register.filter
def get_item(dictionary, key):
    try:
        if dictionary.get(key):
            return dictionary.get(key)
    except:
        return None
    
    