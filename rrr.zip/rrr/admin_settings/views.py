from django.shortcuts import render,redirect
from datetime import date, timedelta
from django.http import HttpResponseRedirect
import datetime
import re

from django.db.models.functions import Concat
from django.contrib import messages
from datetime import datetime, date
from django.conf import settings
from django.template.loader import render_to_string
from django.http import HttpResponse
import json
from django.http import JsonResponse
from admin_settings.models import Admin_user
from admin_settings.models import Projects
from admin_settings.models import Enquiries

from django.core.files.storage import FileSystemStorage

# Create your views here.
def admin_login(request):
	error_msg=user_name=password=error_user_name=error_password=error_user=login_user_info=remote_ip=""
	is_post=""
	if request.POST:
		is_post="1"
		if request.POST.get('username'):
			user_name = request.POST.get('username')
		else:
			error_user_name="Empty or invalid username"
			
		if request.POST.get('password'):
			password = request.POST.get('password')
		else:
			error_password="Empty or invalid password"
			
		if user_name and password:
			
			try:
				login_user_info = Admin_user.objects.get(user_name=user_name,password=password,status=1)   
				
			except Admin_user.DoesNotExist:
			
				login_user_info = None
				
			if login_user_info:

				request.session['loggedin_user_id']=login_user_info.id
				request.session['loggedin_user_uname']=login_user_info.user_name
				request.session['loggedin_user_fname']=login_user_info.first_name
				request.session['loggedin_user_lname']=login_user_info.last_name
				redirect_url = "/admin/projects/"
				return HttpResponseRedirect(redirect_url)
				
			else:
				error_user="Invalid username or password"
				
	error_msg={
			'user_name':error_user_name,
			'password':error_password,
			'error_user':error_user,
	}
	return render(request,'login.html',{'error_msg':error_msg,'user_name':user_name})
    
def projects(request):
	if "loggedin_user_id" not in request.session:
		return HttpResponseRedirect("/admin")
		
	projects=""
	keyword=project_type=visibility=""
	search_value = {}
	projects = Projects.objects.all()
	if request.POST:
		if request.POST.get('keyword'):
			keyword=request.POST.get('keyword')
		if request.POST.get('project_type'):
			project_type = request.POST.get('project_type')
		if request.POST.get('visibility'):
			visibility = request.POST.get('visibility')
			
	if keyword or project_type or visibility:
		if keyword:
			projects = projects.filter(name__contains=keyword)
		if project_type:
			projects = projects.filter(type=project_type)
		if visibility:
			projects = projects.filter(visible=visibility)
	
	image_url = settings.SITE_URL
	search_value = {
					'keyword':keyword,
					'project_type':project_type,
					'visibility':visibility,
					}
	return render(request,'projects.html',{'projects_info':projects,'image_url':image_url,'search_value':search_value})
	
def add_project(request):
	
	if "loggedin_user_id" not in request.session:
		return HttpResponseRedirect("/admin")
		
	project_name=project_type=visibility=description=uploaded_file_url=""
	error_project_name=error_project_type=error_visibility=""
	form_value={}
	error_msg={}
	# print(request.POST)
	if request.POST:
		if request.POST.get('project_name'):
			project_name = request.POST.get('project_name')
		else:
			error_project_name="Empty or invalid Project name"
			
		if request.POST.get('project_type'):
			project_type = request.POST.get('project_type')
		else:
			error_project_type="Empty or invalid Project type"
			
		if request.POST.get('visibility'):
			visibility = request.POST.get('visibility')
		else:
			error_visibility="Empty or invalid Project visibility"
		if request.POST.get('description'):
			description = request.POST.get('description')
		
		created_on = datetime.utcnow() 
		created_by = request.session['loggedin_user_id']
		if project_name and project_type and visibility:
			try:
				if request.FILES['image']:
					myfile = request.FILES['image']
					fs = FileSystemStorage()
					filename = fs.save(myfile.name, myfile)
					uploaded_file_url = fs.url(filename)
			except:
				uploaded_file_url=""
			Projects(name=project_name,image=uploaded_file_url,description=description,type=project_type,visible=visibility,created_on=created_on,created_by=created_by).save()
			redirect_url = "/admin/projects/"
			return HttpResponseRedirect(redirect_url)
	# print(project_name)
	form_value={
				'name':project_name,
				'type':project_type,
				'description':description,
				'visible':visibility,
				}
	error_msg={
				'error_project_type':error_project_type,
				'error_project_name':error_project_name,
				'error_visibility':error_visibility,
	}
	return render(request,'add_project.html',{'error_msg':error_msg,'form_value':form_value,'title_name':"Add"})

def edit_project(request,id):
	
	if "loggedin_user_id" not in request.session:
		return HttpResponseRedirect("/admin")
		
	project_name=project_type=visibility=description=uploaded_file_url=""
	error_project_name=error_project_type=error_visibility=""
	form_value={}
	error_msg={}
	# print(request.POST)
	form_value = Projects.objects.get(id=id)
	if request.POST:
		if request.POST.get('project_name'):
			project_name = request.POST.get('project_name')
		else:
			error_project_name="Empty or invalid Project name"
			
		if request.POST.get('project_type'):
			project_type = request.POST.get('project_type')
		else:
			error_project_type="Empty or invalid Project type"
			
		if request.POST.get('visibility'):
			visibility = request.POST.get('visibility')
		else:
			error_visibility="Empty or invalid Project visibility"
		if request.POST.get('description'):
			description = request.POST.get('description')
		
		modified_on = datetime.utcnow() 
		# modified_by = request.session['loggedin_user_id']
		if project_name and project_type and visibility:
			try:
				if request.FILES['image']:
					myfile = request.FILES['image']
					fs = FileSystemStorage()
					filename = fs.save(myfile.name, myfile)
					uploaded_file_url = fs.url(filename)
				else:
					uploaded_file_url = form_value.image
			except:
				uploaded_file_url = form_value.image
			Projects.objects.filter(id=id).update(name=project_name,image=uploaded_file_url,description=description,type=project_type,visible=visibility,modified_on=modified_on)
			
			redirect_url = "/admin/projects/"
			return HttpResponseRedirect(redirect_url)
	# print(project_name)
		form_value={
					'name':project_name,
					'type':project_type,
					'description':description,
					'visible':visibility,
					}
	error_msg={
				'error_project_type':error_project_type,
				'error_project_name':error_project_name,
				'error_visibility':error_visibility,
	}
	
	return render(request,'add_project.html',{'error_msg':error_msg,'form_value':form_value,'title_name':"Edit"})

def delete_project(request,id):	
	
	if "loggedin_user_id" not in request.session:
		return HttpResponseRedirect("/admin")
		
	Projects.objects.filter(id=id).delete()
	redirect_url = "/admin/projects/"
	return HttpResponseRedirect(redirect_url)

def enquiries(request):
	
	if "loggedin_user_id" not in request.session:
		return HttpResponseRedirect("/admin")
		
	enquiries = ""
	enquiries = Enquiries.objects.all()
    
	return render(request,'enquiries.html',{'enquiries_info':enquiries})
	
	
def delete_enquiry(request):
	
	if "loggedin_user_id" not in request.session:
		return HttpResponseRedirect("/admin")
		
	redirect_url = "/admin/enquiries/"
	return HttpResponseRedirect(redirect_url)
	
def logout(request):

	if "loggedin_user_id" in request.session:
		del request.session['loggedin_user_id']
	if "loggedin_user_uname" in request.session:
		del request.session['loggedin_user_uname']
	if "loggedin_user_fname" in request.session:
		del request.session['loggedin_user_fname']
	if "loggedin_user_lname" in request.session:
		del request.session['loggedin_user_lname']
		
	redirect_url = "/admin"
	return HttpResponseRedirect(redirect_url)
	